(function() {
  "use strict";

  angular.module('public')
  .controller('SignUpController', SignUpController);


  /**
   * Handles signup
   */
  //SignUpController.$inject = ['$state'];
  function SignUpController() {
    var $ctrl = this;
    $ctrl.user = {};

  }
})();
